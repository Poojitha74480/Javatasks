package com.hexaware.collectionsproject;

public class Sellerdisplay {

	public static void main(String[] args) {
		Sellerlist sc = new Sellerlist();
		
		sc.addsellers();
		
		sc.displayAllSellers();
		

	}

}
