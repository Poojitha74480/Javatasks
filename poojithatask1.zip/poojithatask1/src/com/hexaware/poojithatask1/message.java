package com.hexaware.poojithatask1;


@FunctionalInterface
public interface message {
	void quotation();//SAM
}